
################################################################################################
list_of_phrases={
("than","or"),
("then","or"),
("wether","or"),
("else","if"),
}
conditions_word_list = {
"although", 
"and", 
"as", 
"because", #c/d
"but",  #c/d
"if", 
"or", 
"since", 
"than", 
"though", 
"until", 
"whether", 
"while",
"else",
"when",
"then",
"than",
#"shall",
#"should",
}
conditions_word_list = conditions_word_list.union({ '_'.join(phrase) for phrase in list_of_phrases})
##################################Polarion Credentials######################################################
info_dict = {
    'url' : 	"http://polarionprod1.delphiauto.net/polarion"	,	# "https://almdemo.polarion.com/polarion"
    'username': "xjh0qx"                                        ,	#"bhavesh.itankar@gmail.com"  #xjh0qx
    'password': "aptiv@june20"	                                ,	#"VnT4wryC$"                  #aptiv@june20
    'project_id' : "10033679_MY22_AUDI_PODS_SDPS"            	,	#'bhavesh.itankar_gmail.com'
    'type_ids' : ['stakeholderRequirement','systemRequirement']	,
    'jiraURL': r"http://jiraprod1.delphiauto.net:8080"			,
    'jiraURL_1': r"http://nlskaa56.europe.delphiauto.net:8080"  ,
    'block_size' : 1000                                         ,
    'block_num' : 0                                             ,
    'Project_Name' : "DVJ"	                                    ,
    'CHROME_DRIVER_PATH' : r"C:\Webdriver\chromedriver.exe"		,
    'conditions_word_list' : conditions_word_list				,
    'list_of_phrases' : list_of_phrases							,
    'REVIEW_DBLINK' : "http://pep.usinkok.northamerica.delphiauto.net:8075/projectdb/public/" ,
    'S_URL' : "https://lnttsgroup.sharepoint.com/sites/PODS/"
}
