import pandas as pd 
import win32com.client
import os
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import glob
from pathlib import Path
import re
import pyautogui
#from settings import *
# from jira_extra import jira_extract 




def sharepoint_data(CHROME_DRIVER_PATH,S_URL):
    home = str(Path.home())
    EMAILFIELD = (By.ID, "i0116")
    PASSWORDFIELD = (By.ID, "i0118")
    NEXTBUTTON = (By.ID, "idSIButton9")
    VERIFY = (By.ID, "idTxtBx_SAOTCC_OTC")
    #S_URL = r"https://lnttsgroup.sharepoint.com/sites/PODS/Lists/PODS_Audi/AllItems.aspx"
    # xpath = (By.XPATH,"//a[@href='/sites/TicketTracker/Lists/NewList/AllItems.aspx']")
    classpath = (By.CSS_SELECTOR,"[aria-label='Task ID Required Field, empty, field editor.']")
    ticket_id = (By.CSS_SELECTOR,"[aria-label='Ticket ID, empty, field editor.']")
    ticket_type = (By.CSS_SELECTOR,"[aria-label='Story/Sub-Task, empty, field editor.']")
    Release = (By.CSS_SELECTOR,"[aria-label='Release, empty, field editor.']")
    summary = (By.CSS_SELECTOR,"[aria-label='Summary, empty, field editor.']")
    status = (By.CSS_SELECTOR,"[aria-label='Status, empty, field editor.']")
    createdon = (By.CSS_SELECTOR,"[aria-label='Created on']")
    duedate = (By.CSS_SELECTOR,"[aria-label='Due Date']")
    customdate = (By.CSS_SELECTOR,"[aria-label='Custom Date']")
    response_comp = (By.CSS_SELECTOR,"[aria-label='Responsible Competency, empty, field editor.']")
    assign = (By.CSS_SELECTOR,"[aria-label='Assignee, empty, field editor.']")
    label = (By.CSS_SELECTOR,"[aria-label='Labels, empty, field editor.']")
    reassigned = (By.CSS_SELECTOR,"[aria-label='Reassigned?, empty, field editor.']")
    reassign_yes = (By.CSS_SELECTOR,"[aria-label='Yes']")
    reassign_no = (By.CSS_SELECTOR,"[aria-label='No']")
    save_details = (By.NAME,"Save")
    docs = (By.NAME,"Documents")
    upload = (By.NAME,"Upload")
    commands = (By.CSS_SELECTOR,"[aria-label='Commands']")
    
    new = (By.NAME,"New")
    overwrite = (By.CSS_SELECTOR,"[aria-label='Show error']")
    # add_file = (By.CLASS_NAME,"od-Button OperationMonitor-itemButtonAction")
    add_file = (By.NAME,"Add file")
    excel_export = (By.NAME,"Export to Excel")
    #PATH = f"{os.getcwd()}\chromedriver.exe"
    folder_dump = "Sharepoint_exp"
    parent_dir = os.getcwd()


    chromeoptions = webdriver.ChromeOptions()
    chromeoptions.add_argument('--ignore-certificate-errors-spki-list')
    chromeoptions.add_argument('--ignore-ssl-errors')
    browser = webdriver.Chrome(CHROME_DRIVER_PATH,options=chromeoptions)
    browser.maximize_window()
    browser.get(S_URL)

    # # wait for email field and enter email
    # WebDriverWait(browser, 10).until(EC.element_to_be_clickable(EMAILFIELD)).send_keys("Aishwarya.BS@ltts.com")

    # # Click Next
    # WebDriverWait(browser, 10).until(EC.element_to_be_clickable(NEXTBUTTON)).click()

    # # wait for password field and enter password
    # WebDriverWait(browser, 10).until(EC.element_to_be_clickable(PASSWORDFIELD)).send_keys("Sept#20332020")

    # # Click Login - same id?
    # WebDriverWait(browser, 10).until(EC.element_to_be_clickable(NEXTBUTTON)).click()

    # time.sleep(10)
    # WebDriverWait(browser, 20).until(EC.element_to_be_clickable(NEXTBUTTON)).click()

    # time.sleep(40)
    
    
    # WebDriverWait(browser, 30).until(EC.element_to_be_clickable(add_file)).click()
    WebDriverWait(browser, 600).until(EC.element_to_be_clickable(excel_export)).click()

    time.sleep(10)

    download_path = os.path.join(home,"Downloads")
    os.chdir(download_path)
    myFiles = glob.glob('*.iqy')
    latest = max(myFiles,key=os.path.getctime)
    print(latest)

    indiv_key = set()
    new_items = []
    excel = win32com.client.Dispatch("Excel.Application")
    excel.DisplayAlerts = False
    excel.Visible = False
    trgName_file = os.path.join(download_path,latest)
    down_num = re.search("query(.*?).iqy",latest).group()
    doc = excel.Workbooks.Open(trgName_file)
    ExcelOrg = trgName_file.replace(latest,f"query{down_num}.xlsx")
    doc.SaveAs(Filename = ExcelOrg,FileFormat = 51)
    doc.Close()
    cols_consider = ['Ticket ID','Title','Story/Sub-Task','Release','Summary','Status','Created on','Due Date','Custom Date','Responsible Competency','Assignee','Labels','Reassigned?']
    time.sleep(10)
    dump = pd.read_excel(ExcelOrg,converters = {'Created on':str,'Due Date': str,'Custom Date':str,'Release':str},usecols=cols_consider)
    dict_dump = dump.to_dict(orient = 'records')
    temp_dir_1 = os.getcwd()
    os.chdir(parent_dir)
    file_1 = pd.read_excel(r"..\..\outputs\Report.xlsx",converters = {'Created on':str,'Due Date': str,'Custom Date':str,'Release':str})
    os.chdir(temp_dir_1)
    dict_store = file_1.to_dict(orient = 'records')
    pair_add = zip(dict_dump,dict_store)
    updated_tup = []     
    tup = [(each_store,each_dump) for each_store in dict_store for each_dump in dict_dump if each_store['Title'] == each_dump['Title'] if each_store!=each_dump]
    for each_tup in tup:
        if 'Reassigned?' not in each_tup[0]:
            each_tup[0]['Reassigned?'] = each_tup[1]['Reassigned?']
            if each_tup[0] != each_tup[1]:
                updated_tup.append((each_tup[0],each_tup[1]))


    joint_dict = dict_dump+dict_store
    for each_key in joint_dict:
        indiv_key.add(each_key['Title'])
    exist_keys = [item['Title'] for item in dict_dump]
    diff_keys = indiv_key.difference(set(exist_keys))
    for indiv_key in diff_keys:
        for new_key in dict_store:
            dict_store_key = list(new_key.values()) 
            if indiv_key in dict_store_key:
                if new_key not in new_items:
                    new_items.append(new_key)

    print(updated_tup)
    # print(new_items)

    time.sleep(2)

    for each in updated_tup:
        title = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.LINK_TEXT,f"{each[0]['Title']}")))
        time.sleep(5)
        title.click()
        WebDriverWait(browser, 40).until(EC.element_to_be_clickable(((By.NAME,'Edit all')))).click()
        Release = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Release, {each[1]['Release']}, field editor.']")))
        Release.click()
        Release.send_keys(str(each[0]['Release']))
        summary = WebDriverWait(browser, 40).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Summary, {each[1]['Summary']}, field editor.']")))
        summary.click()
        summary.send_keys(str(each[0]['Summary']))
        status = WebDriverWait(browser, 40).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Status, {each[1]['Status']}, field editor.']")))
        status.click()
        status.send_keys(str(each[0]['Status']))
        responsible_competency = WebDriverWait(browser, 40).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Responsible Competency, {each[1]['Responsible Competency']}, field editor.']")))
        responsible_competency.click()
        responsible_competency.send_keys(str(each[0]['Responsible Competency']))
        assignee = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Assignee, {each[1]['Assignee']}, field editor.']")))
        assignee.click()
        assignee.send_keys(str(each[0]['Assignee']))
        labels = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Labels, {each[1]['Labels']}, field editor.']")))
        labels.click()
        labels.send_keys(str(each[0]['Labels']))
        if str(each[0]['Created on']) == "nan":
            pass
        else:
            created_date = re.findall(r'\d+',str(each[0]['Created on']))
            created_date[0],created_date[2] = created_date[2],created_date[0]
            created_date_formatted = '-'.join(created_date)
            created = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Created on']")))
            created.click()
            created.send_keys(created_date_formatted)
        if str(each[0]['Due Date']) == "nan":
            pass
        else:
            due = re.findall(r'\d+',str(each[0]['Due Date']))
            due[0],due[2] = due[2],due[0]
            due_formatted = '-'.join(due)
            due_date = WebDriverWait(browser, 40).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Due Date']")))
            due_date.click()
            due_date.send_keys(due_formatted)
        if str(each[0]['Custom Date']) == "nan":
            pass
        else:
            custom = re.findall(r'\d+',str(each[0]['Custom Date']))
            custom[0],custom[2] = custom[2],custom[0]
            custom_formatted = '-'.join(custom)
            custom_date = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Custom Date']")))
            custom_date.click()
            custom_date.send_keys(custom_formatted)
        reassigned_click = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Reassigned?, {each[1]['Reassigned?']}, field editor.']")))
        reassigned_click.click()
        WebDriverWait(browser, 30).until(EC.element_to_be_clickable(reassign_yes)).click()
        time.sleep(2)
        WebDriverWait(browser, 10).until(EC.element_to_be_clickable(save_details)).click()
        time.sleep(3)
        WebDriverWait(browser, 30).until(EC.element_to_be_clickable(((By.CSS_SELECTOR,"[aria-label='Close']")))).click()
        time.sleep(3)
        
        time.sleep(1)

    for each_new in new_items:
        if str(each_new['Labels']) != "nan":
            WebDriverWait(browser, 30).until(EC.element_to_be_clickable(new)).click()
            time.sleep(3)
            WebDriverWait(browser, 30).until(EC.element_to_be_clickable(classpath)).send_keys(str(each_new["Title"]))
            WebDriverWait(browser, 30).until(EC.element_to_be_clickable(ticket_id)).send_keys(str(each_new["Ticket ID"]))
            WebDriverWait(browser, 30).until(EC.element_to_be_clickable(ticket_type)).send_keys(str(each_new["Story/Sub-Task"]))
            Release = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Release, empty, field editor.']")))
            Release.click()
            Release.send_keys(str(each_new['Release']))
            summary = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Summary, empty, field editor.']")))
            summary.click()
            summary.send_keys(str(each_new['Summary']))
            status = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Status, empty, field editor.']")))
            status.click()
            status.send_keys(str(each_new['Status']))
            responsible_competency = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Responsible Competency, empty, field editor.']")))
            responsible_competency.click()
            responsible_competency.send_keys(str(each_new['Responsible Competency']))
            assignee = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Assignee, empty, field editor.']")))
            assignee.click()
            assignee.send_keys(str(each_new['Assignee']))
            labels = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Labels, empty, field editor.']")))
            labels.click()
            labels.send_keys(str(each_new['Labels']))
            if str(each_new['Created on']) == "nan":
                pass
            else:
                created_date = re.findall(r'\d+',str(each_new['Created on']))
                created_date[0],created_date[2] = created_date[2],created_date[0]
                created_date_formatted = '-'.join(created_date)
                created = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Created on']")))
                created.click()
                created.send_keys(created_date_formatted)
            if str(each_new['Due Date']) == "nan":
                pass
            else:
                due = re.findall(r'\d+',str(each_new['Due Date']))
                due[0],due[2] = due[2],due[0]
                due_formatted = '-'.join(due)
                due_date = WebDriverWait(browser, 40).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Due Date']")))
                due_date.click()
                due_date.send_keys(due_formatted)
            if str(each_new['Custom Date']) == "nan":
                pass
            else:
                custom = re.findall(r'\d+',str(each_new['Custom Date']))
                custom[0],custom[2] = custom[2],custom[0]
                custom_formatted = '-'.join(custom)
                custom_date = WebDriverWait(browser, 30).until(EC.element_to_be_clickable((By.CSS_SELECTOR,f"[aria-label='Custom Date']")))
                custom_date.click()
                custom_date.send_keys(custom_formatted)
            WebDriverWait(browser, 10).until(EC.element_to_be_clickable(save_details)).click()
            time.sleep(3)

    WebDriverWait(browser,600).until(EC.presence_of_element_located(commands))
    WebDriverWait(browser, 30).until(EC.element_to_be_clickable(docs)).click()
    time.sleep(10)
    WebDriverWait(browser, 30).until(EC.element_to_be_clickable(upload)).click()
    # element.send_keys(r"C:\Users\hari_\Documents\My Received Files\backups_1.2\scripts\Data_extractors\Report.xlsx")
    time.sleep(5)
    action = ActionChains(browser)
    action.key_down(Keys.CONTROL).send_keys(Keys.ARROW_DOWN).key_up(Keys.CONTROL).send_keys(Keys.ENTER).perform()
    # find_element_by_visible_text("Files").click()
    time.sleep(5)
    pyautogui.write(f"{os.getcwd()}\\Report.xlsx") 
    pyautogui.press('enter')
    time.sleep(5)
    if browser.find_elements_by_css_selector("[aria-label='Show error']"):
        WebDriverWait(browser,30).until(EC.presence_of_element_located(overwrite)).click()
        time.sleep(5)
        action.send_keys(Keys.TAB * 2).send_keys(Keys.ENTER)
        time.sleep(5)
        action.send_keys(Keys.TAB * 3).send_keys(Keys.ENTER)
        action.perform()

if __name__== "__main__" :
    # jira_extract()
    sharepoint_data()
    