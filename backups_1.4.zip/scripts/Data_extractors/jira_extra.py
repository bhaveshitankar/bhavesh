 ################################################################################################
    #                                                                                      #
    #                                                                                      #
    #                         Title: Automation for Jira Analysis Pro                      #
    #                         Author: Kiran Lonkar                                         #
    #                         Version: V10.0                                               #
    #                                                                                      #
    #                                                                                      #
################################################################################################

######################## Packages used for Automation ##########################################
from jira import JIRA
from re import findall
from pandas import DataFrame
import pandas as pd
def jira_login(jiraUserName,jiraPassword,jiraURL,jiraURL_1):
   working_link = ''
   print("\n**************************************** Login To JIRA *****************************************")
   try:
       options = {'server': jiraURL}
       jira = JIRA(options, basic_auth=(jiraUserName, jiraPassword))
       working_link = jiraURL
   except:
       options = {'server': jiraURL_1}
       jira = JIRA(options, basic_auth=(jiraUserName, jiraPassword))
       working_link = jiraURL_1
       pass
   return jira,working_link
   print("\n*********************************** JIRA Login Successfull..! **********************************")
def jira_hack_1(block_num,block_size,Project_Name,jira,working_link):
   issues_1 = DataFrame()
   allissues = []
   print("\n******************* Please wait Data Extraction is started for "+Project_Name+" Project *********************\n")
   while True:
       start_id = int(block_num)*int(block_size)
       ise = jira.search_issues('project='+Project_Name, startAt=start_id, maxResults=int(block_size))
       if len(ise) == 0:
           break
       block_num +=1
       for iissee in ise:
           allissues.append(iissee)
   print('Total issues Found for '+Project_Name+' Project :', len(allissues))
   for issue in allissues: 
        try:
            desc = ' '.join(map(str, issue.fields.description.split('\n')))
        except:
            desc = issue.fields.description
            pass
        try:
            acc = ' '.join(map(str, issue.fields.customfield_10554.split('\n')))
        except:
            acc = issue.fields.customfield_10554
            pass
        if len(issue.fields.fixVersions)!=0:
            ff = issue.fields.fixVersions[-1].name
            try:
                rel_date = issue.fields.fixVersions[-1].releaseDate
            except:
                rel_date = ''
                pass
        else:
            ff = ""
            rel_date = ""
        if len(issue.fields.labels)!=0:
           lab = issue.fields.labels[0]
        else:
            lab = ""
        if len(issue.fields.subtasks)!=0:
            subt = ','.join(map(str, issue.fields.subtasks)) 
        else:
            subt = ""
        raw = findall(r"(.*)T", issue.fields.created)[0]
        try:
            feat = issue.fields.customfield_10134.value
        except:
            feat = ""
            pass
        try:
            func = issue.fields.customfield_10200.value
        except:
            func = ""
            pass
        if len(issue.fields.versions)!=0:
            aff_ver = issue.fields.versions[0]
        else:
            aff_ver=''
        if len(issue.fields.components)!=0:
            comp = issue.fields.components[0].name
        else:
            comp = ''
        try:
            org_ist = issue.fields.aggregatetimeoriginalestimate/3600
        except:
            org_ist = ''
            pass
        try:
            sevr = issue.fields.customfield_10147.value
        except:
            sevr = ''
            pass
        try:
            org_ph = issue.fields.customfield_10142.value
        except:
            org_ph = ''
            pass
        try:
            det_ph = issue.fields.customfield_10140.value
        except:
            det_ph = ''
            pass
        try:
            RC =  issue.fields.customfield_10553.value
        except:
            RC = ''
            pass
        try:
            proj =  issue.fields.project.name
        except:
            proj = ''
            pass
        try:
            summ =  issue.fields.summary
        except:
            summ = ''
            pass
        try:
            stat =  issue.fields.status.name
        except:
            stat = ''
            pass
        try:
            assi =  issue.fields.assignee
        except:
            assi = ''
            pass
        try:
            prio =  issue.fields.priority.name
        except:
            prio = ''
            pass
        try:
            D_Date =  issue.fields.duedate
        except:
            D_Date = ''
            pass
        try:
            repo =  issue.fields.reporter
        except:
            repo = ''
            pass
        try:
            ityp =  issue.fields.issuetype.name
        except:
            ityp = ''
            pass
        try:
            cd1 =  issue.fields.customfield_10545
        except:
            cd1 = ''
            pass
        try:
            ct1 =  issue.fields.customfield_10555
        except:
            ct1 = ''
            pass
        try:
            ctb =  issue.fields.customfield_11033
        except:
            ctb = ''
            pass
        try:
            raw = findall(r"(.*)T", issue.fields.created)[0]
        except:
            raw = ''
            pass
        try:
            parent=issue.fields.parent.key
        except:
            parent = issue.key
            pass
        d = {
            #'Key': issue.key, 
            'Jira ID': issue.key, 
            'Summary': summ,
            'Parent_ID': parent,
            'Status': stat,
            'Assignee': assi,
            'created' : raw,
            'Affects Version/s': aff_ver,
            'Description': desc,
            'Analysis/Cause' : acc,
            'Component/s': comp,
            'Feature' : feat,
            'Function' : func,
            'Responsible Competency' :RC,
            'Labels' : lab,
            'Fix Version/s': ff,
            'Due Date' : D_Date,
            'Reporter': repo,
            'Issue Type' : ityp,
            'Severity' : sevr,
            'Custom_Date_1': cd1,
            'Sub_Tasks': subt,
            'Jira url' : f'{working_link}/browse/{issue.key}',
        }

        issues_1 = issues_1.append(d, ignore_index=True)
   issues_1.head()
   #issues_1.to_excel(r"..\\..\\outputs\\Report.xlsx", sheet_name=Project_Name, encoding="utf-8", header=True, index=False)
   print ("\n******************************* Data Extraction is Done...! ************************************\n")
   return issues_1

def jira_extract(info_dict):
    jira,working_link =jira_login(info_dict['username'],info_dict['password'],info_dict['jiraURL'],info_dict['jiraURL_1'])
    return jira_hack_1(info_dict['block_num'],info_dict['block_size'],info_dict['Project_Name'],jira,working_link)


if __name__== "__main__" :
    info_dict = {
        'url' : 	"http://polarionprod1.delphiauto.net/polarion"	,	
        'username': "xjh0qx"                                        ,	
        'password': "aptiv@june20"	                                ,	
        'project_id' : "10033679_MY22_AUDI_PODS_SDPS"            	,	
        'type_ids' : ['stakeholderRequirement','systemRequirement']	,
        'jiraURL': r"http://jiraprod1.delphiauto.net:8080"			,
        'jiraURL_1': r"http://nlskaa56.europe.delphiauto.net:8080"  ,
        'block_size' : 1000                                         ,
        'block_num' : 0                                             ,
        'Project_Name' : "DVJ"	                                    ,
        }
    jira_extract(info_dict)
