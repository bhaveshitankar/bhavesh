Requirements :
    python >= 3.7.3
If you are using the scripts for first time:
    1. Rename folder "rename_me_to_outputs" to "outputs"
    2. Please run First_time_installer.py with any python interpretor.
    3. Give path for 3.7.X (X>=3) python interpretor path.
    4. The code will run and install the needed stuff. And generate "run_all_bat.bat"
    5. Double click "run_all_bat.bat" to run the exe.

If Above process is done you can directly click "run_all_bat.bat" to start the exicution.
   