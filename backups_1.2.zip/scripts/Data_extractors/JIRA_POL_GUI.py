from tkinter import filedialog as fd
import tkinter as tk
import os
import copy 


class polarion_gui:
    from tkinter import messagebox as mb
    def starter(self, root):
        self.root = root 
        self.root.title('Polarion Jira SPO Tool')
        self.root.geometry('{}x{}'.format(950, 750))
        self.root.resizable(0,0)
        
        self.top_frame  = tk.Frame(self.root, bg='slate gray', width=950, height=250, padx=3, pady=3)
        self.center     = tk.Frame(self.root, bg='slate gray', width=950,  height=350, padx=3, pady=3)
        self.btm_frame  = tk.Frame(self.root, bg='slate gray', width=950, height=250, pady=3)

        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        
        self.top_frame.grid(row=0, sticky="nsew")
        self.center.grid(row=1, sticky="nsew")
        self.btm_frame.grid(row=2, sticky="nsew")
       
###############################################################################################################################################################################################

        self.jira_project_label = tk.Label(self.top_frame,text = "Jira",font='Helvetica 10 bold',borderwidth = 12,relief="sunken",width = 15,bg = "black",fg = "white")
        self.jira_project_label.grid(row = 0,column =0, padx = 10,pady =10,sticky = "W")
        self.jira_project_label.configure(font = "Helvetica 10 bold")
        self.project_url = tk.Label(self.top_frame,text = "Select URL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.project_url.grid(row = 1,column =0, padx = 10,pady =10,sticky = "W")
      
        # self.jira_url = tk.Entry(self.top_frame ,width = 100, bg = 'white',borderwidth = 6)
        # self.jira_url.grid(row = 1,column = 1, padx = 10,pady = 10)
        # self.jira_url.insert(0,"Enter the URL")
        # self.jira_url.configure(font='Helvetica 10 bold')

        self.v1 = tk.IntVar()
        self.v1.set(1)
        
        self.radiobutton1 = tk.Radiobutton(self.top_frame,text ="http://jiraprod.europe.delphiauto.net:8080", variable = self.v1, value =1, foreground="blue",activebackground = "PaleGreen1",borderwidth = 3,width = 37,bg = "slate gray")
        self.radiobutton1.grid(row = 1,column = 1, padx = 10,pady = 5,sticky = "W")
        self.radiobutton2 = tk.Radiobutton(self.top_frame,text ="http://nlskaa56.europe.delphiauto.net:8080",variable = self.v1,value = 2, foreground="blue",activebackground = "PaleGreen1",borderwidth = 3,width = 37,bg = "slate gray")
        self.radiobutton2.grid(row = 2,column = 1, padx = 13,pady = 5,sticky = "W")
        self.radiobutton2.configure(font = "Helvetica 11 bold")
        self.radiobutton1.configure(font = "Helvetica 11 bold")

        
        self.jira_user_project_label = tk.Label(self.top_frame,text = "User ID",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_user_project_label.grid(row = 3,column =0, padx = 10,pady =10,sticky = "W")
        
        self.jira_user_id = tk.Entry(self.top_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.jira_user_id.grid(row = 3,column = 1, padx = 10,pady = 10)
        self.jira_user_id.insert(0,"")
        self.jira_user_id.configure(font='Helvetica 10 bold') 
        
        self.jira_pwd_project_label = tk.Label(self.top_frame,text = "Password",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_pwd_project_label.grid(row = 4,column =0, padx = 10,pady =10,sticky = "W")
        
        self.jira_pwd = tk.Entry(self.top_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.jira_pwd.grid(row = 4,column = 1, padx = 10,pady = 10)
        self.jira_pwd.insert(0,"")
        self.jira_pwd.configure(font='Helvetica 10 bold')
        
        
        self.jira_project_name_project_label = tk.Label(self.top_frame,text = "Project Name",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_project_name_project_label.grid(row = 6,column =0, padx = 10,pady =10,sticky = "W")
        
        self.jira_project_name_project_entry = tk.Entry(self.top_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.jira_project_name_project_entry.grid(row = 6,column = 1, padx = 10,pady = 10)
        self.jira_project_name_project_entry.insert(0,"DVJ")
        self.jira_project_name_project_entry.configure(font='Helvetica 10 bold')

        
        self.jira_jql_project_label = tk.Label(self.top_frame,text = "JQL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_jql_project_label.grid(row = 5,column =0, padx = 10,pady =10,sticky = "W")
        
        self.jira_jql_project_entry = tk.Entry(self.top_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.jira_jql_project_entry.grid(row = 5,column = 1, padx = 10,pady = 10)
        self.jira_jql_project_entry.insert(0,"Project name = DVJ")
        self.jira_jql_project_entry.configure(font='Helvetica 10 bold')         
     
       

##################################################################################################################################################################################################

        self.pola_project_label = tk.Label(self.center,text = "Polarion",font='Helvetica 10 bold',borderwidth = 12,relief="sunken",width = 15,bg = "black",fg = "white")
        self.pola_project_label.grid(row = 0,column =0, padx = 10,pady =10,sticky = "W")
        
        self.pola_url = tk.Entry(self.center ,width = 85, bg = 'white',borderwidth = 6)
        self.pola_url.grid(row = 1,column = 1, padx = 10,pady = 10)
        self.pola_url.insert(0,"10033679_MY22_AUDI_PODS_SDPS")
        self.pola_url.configure(font='Helvetica 10 bold')           
           
        self.pola_url_project_label = tk.Label(self.center,text = "Project Name",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.pola_url_project_label.grid(row = 1,column =0, padx = 10,pady =10,sticky = "W")
        
        self.pola_url_1 = tk.Entry(self.center ,width = 85, bg = 'white',borderwidth = 6)
        self.pola_url_1.grid(row = 2,column = 1, padx = 10,pady = 10)
        self.pola_url_1.insert(0,"http://polarionprod1.delphiauto.net/polarion")
        self.pola_url_1.configure(font='Helvetica 10 bold')  
        
        self.pola_proj_name_project_label = tk.Label(self.center,text = "Polarion URL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.pola_proj_name_project_label.grid(row = 2,column =0, padx = 10,pady =10,sticky = "W")
        
        self.pola_url_type_ids = tk.Entry(self.center ,width = 85, bg = 'white',borderwidth = 6)
        self.pola_url_type_ids.grid(row = 3,column = 1, padx = 10,pady = 10)
        self.pola_url_type_ids.insert(0,"stakeholderRequirement,systemRequirement")
        self.pola_url_type_ids.configure(font='Helvetica 10 bold')  
        
        self.pola_proj_name_project_type_ids = tk.Label(self.center,text = "Type_IDS",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.pola_proj_name_project_type_ids.grid(row = 3,column =0, padx = 10,pady =10,sticky = "W")        
        
        # self.pola_url_project_name = tk.Entry(self.center ,width = 100, bg = 'white',borderwidth = 6)
        # self.pola_url_project_name.grid(row = 3,column = 1, padx = 10,pady = 10)
        # self.pola_url_project_name.insert(0,"Enter the Project Name")
        # self.pola_url_project_name.configure(font='Helvetica 10 bold')  
        


######################################################################################################################################################################################################        
        
        self.spo_project_label = tk.Label(self.btm_frame,text = "SPO",font='Helvetica 10 bold',borderwidth = 12,relief="sunken",width = 15,bg = "black",fg = "white")
        self.spo_project_label.grid(row = 0,column =0, padx = 10,pady =10,sticky = "W")
       
        self.spo_url_project_label = tk.Label(self.btm_frame,text = "SPO URL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.spo_url_project_label.grid(row = 1,column =0, padx = 10,pady =10,sticky = "W")
        
        self.spo_url_project_entry = tk.Entry(self.btm_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.spo_url_project_entry.grid(row = 1,column = 1, padx = 10,pady = 10)
        self.spo_url_project_entry.insert(0,"https://lnttsgroup.sharepoint.com/sites/PODS")
        self.spo_url_project_entry.configure(font='Helvetica 10 bold')

        self.commonbutton = tk.Button(self.btm_frame,text ="Submit",font='Helvetica 10 bold',padx = 5,pady =5,activebackground = "PaleGreen1",borderwidth = 5)
        self.commonbutton.grid(row = 2,column = 1, padx = 30,pady =5,sticky = "W")
        self.commonbutton.configure(height = 1,width = 12)

        self.quitbutton = tk.Button(self.btm_frame,text ="Quit",font='Helvetica 10 bold',padx = 5,pady =5, command = self.quit,activebackground = "PaleGreen1",borderwidth = 8)
        self.quitbutton.grid(row = 2,column = 2, padx = 30,pady =5,sticky = "W")
        self.quitbutton.configure(height = 1,width = 5)         
        
        
    def quit(self):
        self.root.destroy()
        
######################################################################################################################################################################################################  

          
def main():
    root = tk.Tk()
    app = polarion_gui()
    app = app.starter(root)
    root.mainloop()
	

if __name__ == '__main__':
    main()