import pandas as pd


######################### DO NOT EDIT ##########################################################
jiraURL = r"http://jiraprod1.delphiauto.net:8080" #http://nlskaa56.europe.delphiauto.net:8080/
jiraURL_1 = r"http://nlskaa56.europe.delphiauto.net:8080"
jiraUserName = "xjh0qx" #"fjt46w"
jiraPassword = "aptiv@june20" #"Sanju@2120"
issues_1 = pd.DataFrame()
block_size = 1000
block_num = 0
allissues = []
Project_Name = "DVJ"
################################################################################################

##################################Polarion Credentials######################################################
info_dict = {
    'url' : 	"http://polarionprod1.delphiauto.net/polarion"	,	# "https://almdemo.polarion.com/polarion"
    'username': "xjh0qx"                                        ,	#"bhavesh.itankar@gmail.com"  #xjh0qx
    'password': "aptiv@june20"	                                ,	#"VnT4wryC$"                  #aptiv@june20
    'project_id' : "10033679_MY22_AUDI_PODS_SDPS"            	,	#'bhavesh.itankar_gmail.com'
    'type_ids' : ['stakeholderRequirement','systemRequirement'],	
}
################################################################################################


####################################################################################################
CHROME_DRIVER_PATH = r"C:\Webdriver\chromedriver.exe"
####################################################################################################


###################################################################################################
list_of_phrases={
("than","or"),
("then","or"),
("wether","or"),
("else","if"),
}
conditions_word_list = {
"although", 
"and", 
"as", 
"because", 
"but", 
"if", 
"or", 
"since", 
"than", 
"though", 
"until", 
"whether", 
"while",
"else",
"when",
"then",
"than",
#"shall",
#"should",
}
conditions_word_list = conditions_word_list.union({ '_'.join(phrase) for phrase in list_of_phrases})
###################################################################################################