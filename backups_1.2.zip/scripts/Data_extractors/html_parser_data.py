from bs4 import BeautifulSoup as bs_4
def get_text_data(data):
	soup = bs_4(data, 'lxml')
	return soup.getText()