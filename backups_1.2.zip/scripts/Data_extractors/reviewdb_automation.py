﻿"""This module is created for automating review database and generate review reports"""


__authors__ = "Swethasai Pantangi"
__copyright__ = "Copyright 2019, LTTS"
__version__ = "1.0"
__maintainer__ = "Kaiwalya Damle"
__email__ = "Kaiwalya.Damle@Ltts.com"
__status__ = "Development"



import os
import time
import warnings
from selenium import webdriver
from selenium.webdriver.common.keys import Keys 
import win32com.client as win32
import pandas as pd
import xlsxwriter
from webdriver_manager.chrome import ChromeDriverManager



REVIEW_DBLINK = "http://pep.usinkok.northamerica.delphiauto.net:8075/projectdb/public/"

def get_review_database_report(chrome_driver_path,project_name,username,password):
    """This function will automate review database,
       fetch review information and dump to excel file
    Parameters:
    ----------
    chrome_driver_path : str
        path to the chromedriver executable
    project_name : str
        project name for fetching review report from database
    username : str
        aptiv - netid
    password : str
        aptiv - password

    Returns : 
    -------
    output_xl : excel file
        excel report contains review information for user mentioned project name

    Raises:
    ------
    Exception: 
       1) Will be raised when chromedriver is not installed
       2) Will be raised when Projet Name Is Not Found In Review Database Project List
       3) Will be raised when Time out happend while connecting to server
       4) Will be raised when excel report with the same name is alreday opened 
    """
    warnings.filterwarnings("ignore")
    #checking for chromedriver existence
    if os.path.exists(chrome_driver_path):
      driver = webdriver.Chrome(chrome_driver_path)
    else:
      raise Exception("chromedriver installation not found")
    try:
        # driver = webdriver.Chrome(ChromeDriverManager().install())
        driver.get(REVIEW_DBLINK)
        #select login from homepage
        options = driver.find_element_by_class_name('menu2')
        if options.text == "Login":
            options.click()
            #TODO:
            time.sleep(2)
            login_netid = driver.find_element_by_class_name('linkbutton_green')
            if login_netid.text == "Click HERE to login using your NetID":
                login_netid.click()
                time.sleep(2)
                #connecting to review database by login using netid and password
                driver.get(f"http://{username.strip()}:{password.strip()}@pep.usinkok.northamerica.delphiauto.net/projectdb/public/netauth/auth.php")
                login_ac= driver.find_element_by_class_name('linkbutton_green')
                if login_ac.text == "Use this account":
                    login_ac.click()
                    time.sleep(2)
                    report_search = driver.find_elements_by_css_selector('div a')
                    for each_webele in report_search:
                        if each_webele.text == "Reports▼":
                            each_webele.click()
                        #TODO:display exceptions accordingly
                        elif each_webele.text == " Peer Review Data Dump":
                            each_webele.click()
                            break
                    projects_list = []
                    get_projectlist = driver.find_elements_by_css_selector('select option')
                    for each_project in get_projectlist:
                        projects_list.append(each_project.text)

                    #Fetch report for project_name
                    selected_project = ''
                    for db_project in projects_list:
                        if project_name in db_project:
                            selected_project = db_project
                            break

                    if selected_project == '':
                        raise Exception("Entered Projet Name Is Not Found In Review Database Project List! Please Enter Valid Project Name")

                    print(f"Fetching review database report for project: {selected_project}")   
                    driver.find_element_by_xpath(f'//select[@name="pid"]/option[text()="{selected_project}"]').click()      
                    driver.find_element_by_xpath("//input[@type='submit' and @value='Submit']").click()

                    # perform the ctrl+A and ctrl+c pressing action
                    textarea = driver.find_element_by_xpath('//textarea')
                    textarea.click()
                    driver.find_element_by_xpath("//textarea").send_keys(Keys.CONTROL, "a")
                    driver.find_element_by_xpath("//textarea").send_keys(Keys.CONTROL, "c")

                    try:
                        excel_name = f"review_report_{project_name}.xlsx"
                        output_xl = os.path.join(os.path.dirname(os.path.abspath(__file__)), excel_name)
                        #dump to excel
                        df = pd.read_clipboard() 
                        df.to_excel(output_xl, sheet_name = 'Reviews_list', engine = 'xlsxwriter', index = False)
                        #close all browser windows and ternimate webdriver session
                        driver.quit()
                        return output_xl
                    #TODO:exit from exceptions
                    except xlsxwriter.exceptions.FileCreateError:
                        raise Exception(f"Could not create file at {output_xl}. Please close {excel_name} which has already opened!")
                   
    except:
        raise Exception(""" Exception happend one of the following reasons:
            1)Time out happend while connecting to server!Try again...
            2)check proxy settings """)

def report_beautification(review_reort):
    """This function will check if 'CRNUMBER' column has multiple ticket number 
        and adjust column length for reducing column expansion 
    Parameters:
    ----------
    review_reort : excel file
        excel report contains review information for user mentioned project name
    """
    ticket_dict = dict()
    review_df = pd.read_excel(review_reort)
    crnumber_multi = review_df['CRNUMBER']
    for each_num in crnumber_multi:
        if ',' in str(each_num):
            multival_row = review_df.loc[review_df['CRNUMBER'] == each_num]
            dummy_row = multival_row
            addon_index = int(review_df.loc[review_df['CRNUMBER'] == each_num].index[0])
            ticket_list = each_num.split(",")
            ticket_dict[each_num] = ticket_list
            for idno, _ in enumerate(ticket_list):
                addon_index+=idno
                addon_df = pd.concat([review_df.iloc[:addon_index], multival_row, review_df.iloc[addon_index:]]).reset_index(drop=True)
            review_df = addon_df
    for row_id, multi_tickts in enumerate(review_df['CRNUMBER']): 
        if multi_tickts in ticket_dict.keys():
            replace_val = each_num.replace(each_num, ticket_dict[multi_tickts][0])
            review_df.at[row_id, 'CRNUMBER'] = replace_val
            values = ticket_dict[multi_tickts]
            ticket_dict[multi_tickts] = values[ticket_dict[multi_tickts].index(replace_val)+1:]
    review_df.to_excel(review_reort, sheet_name = 'Reviews_list', engine = 'xlsxwriter', index = False)
    excel = win32.gencache.EnsureDispatch('Excel.Application')
    wb = excel.Workbooks.Open(output_xl)
    ws = wb.Worksheets("Reviews_list")
    ws.Columns.AutoFit()
    wb.Save()
    excel.Application.Quit()

    print(f"Successfully generated review report at {output_xl}")
    return review_df    

if __name__ == "__main__":
    chrome_driver = input("Enter chromederiver path: ")
    dbproject_name = input("Enter Project Database Name: ")
    netid = input("Netid: ")
    paswrd = input("Password: ")
    output_xl = get_review_database_report(chrome_driver, dbproject_name, netid, paswrd)
    report_beautification(output_xl)
