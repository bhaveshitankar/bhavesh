import time
import os
start_time = time.time()
#import os
#import sys
#scripts_folder_path = r'D:\bhavesh\DESKTOP_3\Project_status_Dashboard_KD_works\scripts\Data_extractors'
#if not os.path.exists(scripts_folder_path):
#    print("script folder path is not updated in reportdata.py file")
#    exit()	
#os.system(f'set PYTHONPATH={scripts_folder_path};%PYTHONPATH%')
#os.chdir(scripts_folder_path)
#sys.path.append(scripts_folder_path)
from settings import *
from polarion_data_extractor_faster import pol_data_extractor, data_extractor, pd
from jira_extra import jira_extract
from reviewdb_automation import get_review_database_report , report_beautification
def create_pbi_script_txt():
    path_file = os.getcwd()
    with open(f'{path_file}\\..\\..\\copy_paste_in_pbi.txt','w') as FH:
        str_to_write = f"""
import pandas as pd
mdf = pd.read_excel(r'{path_file}\\..\\..\\outputs\\Merged_Report.xlsx')
pdf = pd.read_excel(r'{path_file}\\..\\..\\outputs\\Pol_Report.xlsx')
jdf = pd.read_excel(r'{path_file}\\..\\..\\outputs\\Jira_Report.xlsx')
        """
        
        FH.write(str_to_write)
def main():
    print("\t---process started :  %s seconds ---" % (time.time() - start_time))
    start_time_temp = time.time()
    pol_obj1 = pol_data_extractor(info_dict)
    print("\t---polarion login time :  %s seconds ---" % (time.time() - start_time_temp))
    start_time_temp = time.time()
    data1 = pol_obj1.get_all_wi_in_project()
    print("\t---time taken for polarion query :  %s seconds ---" % (time.time() - start_time_temp))
    start_time_temp = time.time()
    df_jira = pd.DataFrame(jira_extract())
    print("\t---time taken for jira query :  %s seconds ---" % (time.time() - start_time_temp))
    start_time_temp = time.time()
    data_dict1 = data_extractor(data1,info_dict)
    df_sys_stak = pd.DataFrame(data_dict1) 
    murged_frame = pd.merge(df_sys_stak,df_jira,left_on = 'Jira ID',right_on = 'Jira ID',how='left')
    #start_time_temp = time.time()	
    #pol_obj2 = pol_data_extractor(info_dict2)
    #data2 = pol_obj2.get_all_wi_in_project()
    #data_dict2 = data_extractor(data2,info_dict2)
    #df_sys = pd.DataFrame(data_dict2)
    #output_xl = get_review_database_report(CHROME_DRIVER_PATH,info_dict["project_id"],info_dict["username"],info_dict["password"])
    #review_df = report_beautification(output_xl)
    review_df = pd.read_excel(r'..\..\outputs\review_report_Audi.xlsx')
    murged_frame = pd.merge(murged_frame,review_df,left_on = 'Jira ID',right_on = 'CRNUMBER',how='left')
    murged_frame.to_excel(r"..\..\outputs\Merged_Report.xlsx", sheet_name=Project_Name, encoding="utf-8", header=True, index=False)
    df_sys_stak.to_excel(r"..\..\outputs\Pol_Report.xlsx", sheet_name=Project_Name, encoding="utf-8", header=True, index=False)
    df_jira.to_excel(r"..\..\outputs\Jira_Report.xlsx", sheet_name=Project_Name, encoding="utf-8", header=True, index=False)
    create_pbi_script_txt()
    print("\t---Processing time :  %s seconds ---" % (time.time() - start_time_temp))
    print("---Overall execution time : %s seconds ---" % (time.time() - start_time))
if __name__ == '__main__':
    main()