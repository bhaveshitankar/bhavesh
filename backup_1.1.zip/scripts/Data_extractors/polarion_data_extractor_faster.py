#!/usr/bin/env python
from zeep import Client
from zeep.plugins import HistoryPlugin
import pandas as pd 
import time
import re
#start_time = time.time()



class pol_data_extractor():

	def __init__(self,info_dict):
		'''
			helps to connect to polarion server return a tracker object in self
			input ins a dictionary with url,username,password,project_id,type_ids as keys
		'''
		self.url = info_dict['url']
		self.username = info_dict['username']
		self.password = info_dict['password']
		self.project_id = info_dict['project_id']
		self.type_ids = info_dict['type_ids']
		history = HistoryPlugin()
		session = Client(wsdl=self.url + '/ws/services/SessionWebService?wsdl', plugins=[history])
		session.service.logIn(self.username, self.password)
		tree = history.last_received['envelope'].getroottree()
		sessionHeaderElement = tree.find('.//{http://ws.polarion.com/session}sessionID')
		__tracker = Client(wsdl=self.url + '/ws/services/TrackerWebService?wsdl', plugins=[history])
		__tracker.set_default_soapheaders([sessionHeaderElement])
		
		__tracker.wsdl.messages['{http://ws.polarion.com/TrackerWebService}getModuleWorkItemsRequest'].parts['parameters'].element.type._element[1].nillable = True
		__tracker.service.getModuleWorkItemUris._proxy._binding.get('getModuleWorkItemUris').input.body.type._element[1].nillable = True
		__tracker.service.getModuleWorkItemUris._proxy._binding.get('getModuleWorkItems').input.body.type._element[1].nillable = True
		self.tracker_obj = __tracker
	'''
	c_fields_list = tracker_obj.service.getDefinedCustomFieldKeys(project_id, TYPE)
	all_c_fields_list = [ "customFields.%s.KEY" % field for field in c_fields_list]
	data = tracker_obj.service.queryWorkItems('project.id:%s AND type:%s' % (project_id, TYPE),'id',all_c_fields_list)
	'''	
	
	def get_all_wi_in_project(self):
		'''
			Returns:
				self.data = tracker_obj.service.queryWorkItems(query,'id',all_c_fields_list)
		'''
		if len(self.type_ids):
			filter_str = 'AND (type:'+' OR type:'.join(self.type_ids)+')'
		else:	
			filter_str = ''
		query = 'project.id:%s %s' % (self.project_id,filter_str)
		c_fields_list = [self.tracker_obj.service.getDefinedCustomFieldKeys(self.project_id, type_id) for type_id in self.type_ids]
		all_c_field_list = []
		polarion_default_fields = ['approvals', 'assignee', 'attachments', 'author', 'categories', 'comments', 'created', 'description', 'dueDate', 'externallyLinkedWorkItems', 'hyperlinks', 'id', 'initialEstimate', 'linkedOslcResources', 'linkedRevisions', 'linkedRevisionsDerived', 'linkedWorkItems', 'linkedWorkItemsDerived', 'location', 'outlineNumber', 'plannedEnd', 'plannedIn', 'plannedStart', 'planningConstraints', 'previousStatus', 'priority', 'project', 'remainingEstimate', 'resolution', 'resolvedOn', 'severity', 'status', 'timePoint', 'timeSpent', 'title', 'type', 'updated', 'workRecords'] #'moduleURI'
		for c_field_list in c_fields_list:
			all_c_field_list = all_c_field_list + polarion_default_fields + [ "customFields.%s.KEY" % field for field in c_field_list]
		print('--- [INFO] extracting... ---')
		self.data = self.tracker_obj.service.queryWorkItems(query,'id',all_c_field_list)
		print('--- [DONE] extracting ---')
		return self.data

def customFields_extractor(customFields_keys_value):
	temp_dict = {}
	for field in customFields_keys_value.Custom:
		#print(field.key,field.value)
		temp_dict[field.key] = field.value
	return temp_dict

def data_extractor(data,info_dict):
	data_dict = []
	WI_URI_comm_str = 'subterra:data-service:objects:/default/%s${WorkItem}' % info_dict['project_id']
	module_URI_comm_str = 'subterra:data-service:objects:/default/%s${Module}{moduleFolder}' % info_dict['project_id']
	for dd in data:
		tem_dict = {}
		custom_fields_dict = customFields_extractor(dd.customFields)
		try:
			tem_dict['Type'] = dd.type.id
		except:
			tem_dict['Type'] = ""
		try:	
			tem_dict['ID'] = dd.id
		except:
			tem_dict['ID'] = ""
		try:	
			tem_dict['Space / Document'] = re.findall(r'/modules/(.*?)/workitems/',dd.location)[0]
			#tem_dict['Space / Document'] = "%s / %s" % (custom_fields_dict['_space'], custom_fields_dict['_document'])
		except:
			tem_dict['Space / Document'] = "" 
		try:	
			tem_dict['Status'] = dd.status.id
		except:
			tem_dict['Status'] = ""
		try:	
			tem_dict['Severity'] = dd.severity.id
		except:
			tem_dict['Severity'] = ""
		try:	
			tem_dict['Approvals'] = ';'.join([aprvl.status.id+","+aprvl.user.id for aprvl in dd.approvals.Approval])
		except:
			tem_dict['Approvals'] = ""
		try:	
			tem_dict['Competency To Review'] = ','.join(re.findall(r"'id':\s*'(.*)'",str(custom_fields_dict['competencyToReview'])))
		except:
			tem_dict['Competency To Review'] = ""
		try:	
			tem_dict['Competency To Implement'] = ','.join(re.findall(r"'id':\s*'(.*)'",str(custom_fields_dict['CompetencyToImplement'])))
		except:
			tem_dict['Competency To Implement'] = ""
		try:	
			tem_dict['Competency To Verify'] = ','.join(re.findall(r"'id':\s*'(.*)'",str(custom_fields_dict['competencyToImplement'])))
		except:
			tem_dict['Competency To Verify'] = ""
		try:	
			tem_dict['Safety Level'] = custom_fields_dict['safetyLevel'].id
		except:
			tem_dict['Safety Level'] = ""
		try:	
			tem_dict['Safety Type'] = custom_fields_dict['safetyType'].id
		except:
			tem_dict['Safety Type'] = ""
		try:	
			tem_dict['Linked Work Items'] = ','.join([wi.role.id+': '+wi.workItemURI.replace(WI_URI_comm_str,'') for wi in dd.linkedWorkItems.LinkedWorkItem])
		except:
			tem_dict['Linked Work Items'] = ""
		try:	
			tem_dict['Priority'] = dd.priority.id
		except:
			tem_dict['Priority'] = ""
		try:	
			tem_dict['Jira ID'] = custom_fields_dict['jiraId']
		except:
			tem_dict['Jira ID'] = ""
		try:	
			tem_dict['TS Method'] = custom_fields_dict['tsMethod'].id
		except:
			tem_dict['TS Method'] = ""
		try:	
			tem_dict['_polarion'] = dd.uri
		except:
			tem_dict['_polarion'] = ""
		try:	
			tem_dict['Requirement Category'] = custom_fields_dict['requirementCategory'].id
		except:
			tem_dict['Requirement Category'] = ""
		data_dict.append(tem_dict)
	return data_dict		
if __name__=='__main__':
	##### feed the initial data here .....!!!
	info_dict = {
		'url' : 	"http://polarionprod1.delphiauto.net/polarion"	,	# "https://almdemo.polarion.com/polarion"
		'username': "xjh0qx"       									,	#"bhavesh.itankar@gmail.com"  #xjh0qx
		'password': "aptiv@june20"									,	#"VnT4wryC$"                  #aptiv@june20
		'project_id' : "10033679_MY22_AUDI_PODS_SDPS"            	,	#'bhavesh.itankar_gmail.com'
		'type_ids' : ['systemRequirement','stakeholderRequirement','systemRequirement'],	
				}		

	pol_obj = pol_data_extractor(info_dict)
	data = pol_obj.get_all_wi_in_project()
	data_dict = data_extractor(data,info_dict)
	df = pd.DataFrame(data_dict)
	#pd.concat([df1, df4.reindex(df1.index)], axis=1)
	#df.to_excel(r'..\..\Stak_sys_sw_polarion_dump_1.xlsx')		
			
#print("--- %s seconds ---" % (time.time() - start_time))