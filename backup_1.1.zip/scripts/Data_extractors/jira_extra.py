 ################################################################################################
    #                                                                                      #
    #                                                                                      #
    #                         Title: Automation for Jira Analysis Pro                      #
    #                         Author: Kiran Lonkar                                         #
    #                         Version: V10.0                                               #
    #                                                                                      #
    #                                                                                      #
################################################################################################

######################## Packages used for Automation ##########################################
from jira import JIRA
import re
#import pandas as pd
from settings import *
######################### DO NOT EDIT ##########################################################
#jiraURL = r"http://jiraprod1.delphiauto.net:8080" #http://nlskaa56.europe.delphiauto.net:8080/
#jiraURL_1 = r"http://nlskaa56.europe.delphiauto.net:8080"
#jiraUserName = "fjt46w"
#jiraPassword = "Sanju@2120"
#issues_1 = pd.DataFrame()
#block_size = 1000
#block_num = 0
#allissues = []
#Project_Name = "CVM"
################################################################################################
def jira_login():
   print("\n**************************************** Login To JIRA *****************************************")
   try:
       options = {'server': jiraURL}
       jira = JIRA(options, basic_auth=(jiraUserName, jiraPassword))
   except:
       options = {'server': jiraURL_1}
       jira = JIRA(options, basic_auth=(jiraUserName, jiraPassword))
       pass
   return jira
   print("\n*********************************** JIRA Login Successfull..! **********************************")
def jira_hack_1(block_num,block_size,issues_1,Project_Name,jira):
   allissues = []
   print("\n******************* Please wait Data Extraction is started for "+Project_Name+" Project *********************\n")
   while True:
       start_id = int(block_num)*int(block_size)
       ise = jira.search_issues('project='+Project_Name, startAt=start_id, maxResults=int(block_size))
       if len(ise) == 0:
           break
       block_num +=1
       for iissee in ise:
           allissues.append(iissee)
   print('Total issues Found for '+Project_Name+' Project :', len(allissues))
   for issue in allissues: 
        try:
            desc = ' '.join(map(str, issue.fields.description.split('\n')))
        except:
            desc = issue.fields.description
            pass
        try:
            acc = ' '.join(map(str, issue.fields.customfield_10554.split('\n')))
        except:
            acc = issue.fields.customfield_10554
            pass
        if len(issue.fields.fixVersions)!=0:
            ff = issue.fields.fixVersions[-1].name
            try:
                rel_date = issue.fields.fixVersions[-1].releaseDate
            except:
                rel_date = ''
                pass
        else:
            ff = ""
            rel_date = ""
        if len(issue.fields.labels)!=0:
           lab = issue.fields.labels[0]
        else:
            lab = ""
        if len(issue.fields.subtasks)!=0:
            subt = ','.join(map(str, issue.fields.subtasks)) 
        else:
            subt = ""
        raw = re.findall(r"(.*)T", issue.fields.created)[0]
        try:
            feat = issue.fields.customfield_10134.value
        except:
            feat = ""
            pass
        try:
            func = issue.fields.customfield_10200.value
        except:
            func = ""
            pass
        if len(issue.fields.versions)!=0:
            aff_ver = issue.fields.versions[0]
        else:
            aff_ver=''
        if len(issue.fields.components)!=0:
            comp = issue.fields.components[0].name
        else:
            comp = ''
        try:
            org_ist = issue.fields.aggregatetimeoriginalestimate/3600
        except:
            org_ist = ''
            pass
        try:
            sevr = issue.fields.customfield_10147.value
        except:
            sevr = ''
            pass
        try:
            org_ph = issue.fields.customfield_10142.value
        except:
            org_ph = ''
            pass
        try:
            det_ph = issue.fields.customfield_10140.value
        except:
            det_ph = ''
            pass
        try:
            RC =  issue.fields.customfield_10553.value
        except:
            RC = ''
            pass
        try:
            proj =  issue.fields.project.name
        except:
            proj = ''
            pass
        try:
            summ =  issue.fields.summary
        except:
            summ = ''
            pass
        try:
            stat =  issue.fields.status.name
        except:
            stat = ''
            pass
        try:
            assi =  issue.fields.assignee
        except:
            assi = ''
            pass
        try:
            prio =  issue.fields.priority.name
        except:
            prio = ''
            pass
        try:
            D_Date =  issue.fields.duedate
        except:
            D_Date = ''
            pass
        try:
            repo =  issue.fields.reporter
        except:
            repo = ''
            pass
        try:
            ityp =  issue.fields.issuetype.name
        except:
            ityp = ''
            pass
        try:
            cd1 =  issue.fields.customfield_10545
        except:
            cd1 = ''
            pass
        try:
            ct1 =  issue.fields.customfield_10555
        except:
            ct1 = ''
            pass
        try:
            ctb =  issue.fields.customfield_11033
        except:
            ctb = ''
            pass
        try:
            raw = re.findall(r"(.*)T", issue.fields.created)[0]
        except:
            raw = ''
            pass
        try:
            parent=issue.fields.parent.key
        except:
            parent = issue.key
            pass
        d = {
            #'Key': issue.key, 
            'Jira ID': issue.key, 
            'Summary': summ,
            'Parent_ID': parent,
            'Status': stat,
            'Assignee': assi,
            'created' : raw,
            'Affects Version/s': aff_ver,
            'Description': desc,
            'Analysis/Cause' : acc,
            'Component/s': comp,
            'Feature' : feat,
            'Function' : func,
            'Responsible Competency' :RC,
            'Labels' : lab,
            'Fix Version/s': ff,
            'Due Date' : D_Date,
            'Reporter': repo,
            'Issue Type' : ityp,
            'Severity' : sevr,
            'Custom_Date_1': cd1,
            'Sub_Tasks': subt,
        }

        issues_1 = issues_1.append(d, ignore_index=True)
   issues_1.head()
   issues_1.to_excel(r"Report.xlsx", sheet_name=Project_Name, encoding="utf-8", header=True, index=False)
   print ("\n******************************* Data Extraction is Done...! ************************************\n")
   issues_2 = issues_1
   return issues_2

def jira_extract():
    jira=jira_login()
    issues_2 = jira_hack_1(block_num,block_size,issues_1,Project_Name,jira)
    return issues_2

if __name__== "__main__" :
    jira_extract()
