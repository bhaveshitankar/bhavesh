#import os
import pandas as pd
#os.system(r"D:\bhavesh\DESKTOP_3\Project_status_Dashboard_KD_works\backups_1\run_all_bat.bat")
mdf = pd.read_excel(r'D:\bhavesh\DESKTOP_3\Project_status_Dashboard_KD_works\backups_1\outputs\Merged_Report.xlsx')
pdf = pd.read_excel(r'D:\bhavesh\DESKTOP_3\Project_status_Dashboard_KD_works\backups_1\outputs\Pol_Report.xlsx')
jdf = pd.read_excel(r'D:\bhavesh\DESKTOP_3\Project_status_Dashboard_KD_works\backups_1\outputs\Jira_Report.xlsx')
