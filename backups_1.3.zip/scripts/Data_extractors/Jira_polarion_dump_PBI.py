import time
start_time = time.time()
import os
#from settings import info_dict
from polarion_data_extractor_faster import pol_data_extractor, data_extractor, pd
from jira_extra import jira_extract
from reviewdb_automation import get_review_database_report , report_beautification
from sharepoint_script_new import sharepoint_data

def create_pbi_script_txt():
    path_file = os.getcwd()
    with open(f'{path_file}\\..\\..\\copy_paste_in_pbi.txt','w') as FH:
        str_to_write = f"""
import pandas as pd
mdf = pd.read_excel(r'{path_file}\\..\\..\\outputs\\Merged_Report.xlsx')
pdf = pd.read_excel(r'{path_file}\\..\\..\\outputs\\Pol_Report.xlsx')
jdf = pd.read_excel(r'{path_file}\\..\\..\\outputs\\Jira_Report.xlsx')
        """
        
        FH.write(str_to_write)
def main(info_dict):

    print("\t---process started :  %s seconds ---" % (time.time() - start_time))
	
	
    start_time_temp = time.time()
    pol_obj1 = pol_data_extractor(info_dict)
    print("\t---polarion login time :  %s seconds ---" % (time.time() - start_time_temp))
    start_time_temp = time.time()
    data1 = pol_obj1.get_all_wi_in_project()
    data_dict1 = data_extractor(data1,info_dict)
    df_sys_stak = pd.DataFrame(data_dict1) 
    df_sys_stak.to_excel(r"..\\..\\outputs\\Pol_Report.xlsx", sheet_name=info_dict["Project_Name"], encoding="utf-8", header=True, index=False)
    print("\t---Time taken for polarion query :  %s seconds ---" % (time.time() - start_time_temp))
	
	
    start_time_temp = time.time()
    df_jira = jira_extract(info_dict)
    df_jira.to_excel(r"..\\..\\outputs\\Jira_Report.xlsx", sheet_name=info_dict["Project_Name"], encoding="utf-8", header=True, index=False)
    print("\t---Time taken for jira query :  %s seconds ---" % (time.time() - start_time_temp))
	
	
    start_time_temp = time.time()
    #output_xl = get_review_database_report(info_dict['REVIEW_DBLINK'],info_dict["CHROME_DRIVER_PATH"],info_dict["project_id"],info_dict["username"],info_dict["password"])
    #review_df = report_beautification(output_xl)
    review_df = pd.read_excel(r'..\\..\\outputs\\review_report_Audi.xlsx')	
    print("\t---Time taken for Review DB query :  %s seconds ---" % (time.time() - start_time_temp))

	
    start_time_temp = time.time()
    murged_frame = pd.merge(df_sys_stak,df_jira,left_on = 'Jira ID',right_on = 'Jira ID',how='left')
    murged_frame = pd.merge(murged_frame,review_df,left_on = 'Jira ID',right_on = 'CRNUMBER',how='left')
    murged_frame.to_excel(r"..\\..\\outputs\Merged_Report.xlsx", sheet_name=info_dict["Project_Name"], encoding="utf-8", header=True, index=False)
    #create_pbi_script_txt()
    print("\t---Processing time :  %s seconds ---" % (time.time() - start_time_temp))
	
	
    start_time_temp = time.time()
    sharepoint_data(info_dict["CHROME_DRIVER_PATH"],info_dict['S_URL'])
    print("\t---Time taken for Sharepoint update :  %s seconds ---" % (time.time() - start_time_temp))
	
	
    print("---Overall execution time : %s seconds ---" % (time.time() - start_time))
	
	
if __name__ == '__main__':
    main(info_dict)