import tkinter as tk
from tkinter import ttk
import os
import copy 
from Jira_polarion_dump_PBI import main as main_runner
from settings import list_of_phrases,conditions_word_list
#from sharepoint_script_new import sharepoint_data

class polarion_gui:
    #from tkinter import messagebox as mb
    def starter(self, root):
        self.root = root 
        self.root.title('Polarion Jira SPO Tool')
        self.root.geometry('{}x{}'.format(950, 700))
        self.root.resizable(1,1)
        
        self.top_frame  = tk.Frame(self.root, bg='slate gray', width=950, height=200, padx=3, pady=3)
        self.center     = tk.Frame(self.root, bg='slate gray', width=950,  height=350, padx=3, pady=3)
        self.btm_frame  = tk.Frame(self.root, bg='slate gray', width=950, height=250, pady=3)

        self.root.grid_rowconfigure(1, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        
        self.top_frame.grid(row=0, sticky="nsew")
        self.center.grid(row=1, sticky="nsew")
        self.btm_frame.grid(row=2, sticky="nsew")
       
###############################################################################################################################################################################################

        self.jira_project_label = tk.Label(self.top_frame,text = "Jira",font='Helvetica 10 bold',borderwidth = 12,relief="sunken",width = 15,bg = "black",fg = "white")
        self.jira_project_label.grid(row = 0,column =0, padx = 10,pady =10,sticky = "W")
        self.jira_project_label.configure(font = "Helvetica 10 bold")
        #self.project_url = tk.Label(self.top_frame,text = "Select URL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        #self.project_url.grid(row = 1,column =0, padx = 10,pady =10,sticky = "W")
      
        # self.jira_url = tk.Entry(self.top_frame ,width = 100, bg = 'white',borderwidth = 6)
        # self.jira_url.grid(row = 1,column = 1, padx = 10,pady = 10)
        # self.jira_url.insert(0,"Enter the URL")
        # self.jira_url.configure(font='Helvetica 10 bold')

		# LINK SELECTION FOR JIRA #
        #self.v1 = tk.StringVar()
        #self.v1.set('http://jiraprod.europe.delphiauto.net:8080')
        #self.radiobutton1 = tk.Radiobutton(self.top_frame,text ="http://jiraprod.europe.delphiauto.net:8080", variable = self.v1, value ='http://jiraprod.europe.delphiauto.net:8080', foreground="blue",activebackground = "PaleGreen1",borderwidth = 3,width = 37,bg = "slate gray")
        #self.radiobutton1.grid(row = 1,column = 1, padx = 10,pady = 5,sticky = "W")
        #self.radiobutton2 = tk.Radiobutton(self.top_frame,text ="http://nlskaa56.europe.delphiauto.net:8080",variable = self.v1,value = 'http://nlskaa56.europe.delphiauto.net:8080', foreground="blue",activebackground = "PaleGreen1",borderwidth = 3,width = 37,bg = "slate gray")
        #self.radiobutton2.grid(row = 2,column = 1, padx = 13,pady = 5,sticky = "W")
        #self.radiobutton2.configure(font = "Helvetica 11 bold")
        #self.radiobutton1.configure(font = "Helvetica 11 bold")

        # USER ID LABEL #
        self.jira_user_project_label = tk.Label(self.top_frame,text = "User ID",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_user_project_label.grid(row = 3,column =0, padx = 10,pady =10,sticky = "W")
        
		# USER ID ENTRY #
        self.jira_user_id = tk.Entry(self.top_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.jira_user_id.grid(row = 3,column = 1, padx = 10,pady = 10)
        self.jira_user_id.insert(0,"")
        self.jira_user_id.configure(font='Helvetica 10 bold') 
        
		# Password LABEL#
        self.jira_pwd_project_label = tk.Label(self.top_frame,text = "Password",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_pwd_project_label.grid(row = 4,column =0, padx = 10,pady =10,sticky = "W")
        
		# Password ENYTRY #
        self.jira_pwd = tk.Entry(self.top_frame ,width = 85, bg = 'white',borderwidth = 6,show="*")
        self.jira_pwd.grid(row = 4,column = 1, padx = 10,pady = 10)
        self.jira_pwd.insert(0,"")
        self.jira_pwd.configure(font='Helvetica 10 bold')
        
        # Project name JIRA LABEL#
        self.jira_project_name_project_label = tk.Label(self.top_frame,text = "Project Name",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_project_name_project_label.grid(row = 5,column =0, padx = 10,pady =10,sticky = "W")
        
		# Project name JIRA ENYTRY #
        self.n = tk.StringVar() 
        self.jira_project_name_project_entry = ttk.Combobox(self.top_frame ,width = 85, textvariable = self.n)
        self.jira_project_name_project_entry['values'] = ("Audi","Ford")
        self.jira_project_name_project_entry.grid(row = 5,column = 1, padx = 10,pady = 10)
        self.jira_project_name_project_entry.current(0)  
        #self.jira_project_name_project_entry.insert(0,"DVJ")
        self.jira_project_name_project_entry.configure(font='Helvetica 10 bold')
        self.jira_project_name_project_entry.bind('<<ComboboxSelected>>', self.disabler)

        
        self.jira_jql_project_label = tk.Label(self.top_frame,text = "JQL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.jira_jql_project_label.grid(row = 6,column =0, padx = 10,pady =10,sticky = "W")
        
        self.jira_jql_project_entry = tk.Entry(self.top_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.jira_jql_project_entry.grid(row = 6,column = 1, padx = 10,pady = 10)
        self.jira_jql_project_entry.insert(0,"Project name = DVJ")
        self.jira_jql_project_entry.configure(font='Helvetica 10 bold')         
     
       

##################################################################################################################################################################################################

        self.pola_project_label = tk.Label(self.center,text = "Polarion",font='Helvetica 10 bold',borderwidth = 12,relief="sunken",width = 15,bg = "black",fg = "white")
        self.pola_project_label.grid(row = 0,column =0, padx = 10,pady =10,sticky = "W")
           
        self.pola_url_project_label = tk.Label(self.center,text = "Project Name",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.pola_url_project_label.grid(row = 1,column =0, padx = 10,pady =10,sticky = "W")
        
        self.pola_url = tk.Entry(self.center ,width = 85, bg = 'white',borderwidth = 6)
        self.pola_url.grid(row = 1,column = 1, padx = 10,pady = 10)
        self.pola_url.insert(0,"10033679_MY22_AUDI_PODS_SDPS")
        self.pola_url.configure(font='Helvetica 10 bold')           
        
        self.pola_proj_name_project_label = tk.Label(self.center,text = "Polarion URL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.pola_proj_name_project_label.grid(row = 2,column =0, padx = 10,pady =10,sticky = "W")
        
        self.pola_url_1 = tk.Entry(self.center ,width = 85, bg = 'white',borderwidth = 6)
        self.pola_url_1.grid(row = 2,column = 1, padx = 10,pady = 10)
        self.pola_url_1.insert(0,"http://polarionprod1.delphiauto.net/polarion")
        self.pola_url_1.configure(font='Helvetica 10 bold')  
        
        self.pola_url_type_ids = tk.Entry(self.center ,width = 85, bg = 'white',borderwidth = 6)
        self.pola_url_type_ids.grid(row = 3,column = 1, padx = 10,pady = 10)
        self.pola_url_type_ids.insert(0,"stakeholderRequirement,systemRequirement")
        self.pola_url_type_ids.configure(font='Helvetica 10 bold')  
        
        self.pola_proj_name_project_type_ids = tk.Label(self.center,text = "Type IDs",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.pola_proj_name_project_type_ids.grid(row = 3,column =0, padx = 10,pady =10,sticky = "W")        
        
        # self.pola_url_project_name = tk.Entry(self.center ,width = 100, bg = 'white',borderwidth = 6)
        # self.pola_url_project_name.grid(row = 3,column = 1, padx = 10,pady = 10)
        # self.pola_url_project_name.insert(0,"Enter the Project Name")
        # self.pola_url_project_name.configure(font='Helvetica 10 bold')  
        


######################################################################################################################################################################################################        
        
        self.spo_project_label = tk.Label(self.btm_frame,text = "SPO",font='Helvetica 10 bold',borderwidth = 12,relief="sunken",width = 15,bg = "black",fg = "white")
        self.spo_project_label.grid(row = 0,column =0, padx = 10,pady =10,sticky = "W")
       
        self.spo_url_project_label = tk.Label(self.btm_frame,text = "SPO URL",font='Helvetica 10 bold',borderwidth = 3,relief="sunken",width = 12)
        self.spo_url_project_label.grid(row = 1,column =0, padx = 10,pady =10,sticky = "W")
        
        self.spo_url_project_entry = tk.Entry(self.btm_frame ,width = 85, bg = 'white',borderwidth = 6)
        self.spo_url_project_entry.grid(row = 1,column = 1, padx = 10,pady = 10)
        self.spo_url_project_entry.insert(0,"https://lnttsgroup.sharepoint.com/sites/PODS")
        self.spo_url_project_entry.configure(font='Helvetica 10 bold')

        self.commonbutton = tk.Button(self.btm_frame,text ="Submit",font='Helvetica 10 bold',padx = 5,pady =5, command = self.exicuter ,activebackground = "PaleGreen1",borderwidth = 5)
        self.commonbutton.grid(row = 2,column = 1, padx = 30,pady =5,sticky = "W")
        self.commonbutton.configure(height = 1,width = 12)

        self.quitbutton = tk.Button(self.btm_frame,text ="Quit",font='Helvetica 10 bold',padx = 5,pady =5, command = self.quit,activebackground = "PaleGreen1",borderwidth = 8)
        self.quitbutton.grid(row = 2,column = 2, padx = 30,pady =5,sticky = "W")
        self.quitbutton.configure(height = 1,width = 5)         
        self.disabler('')
        
    def quit(self):
        self.root.destroy()
    def disabler(self,_):
        if self.n.get() == 'Audi' :
        
            self.jira_jql_project_entry.delete(0,tk.END)
            self.jira_jql_project_entry.insert(0,"Project name = DVJ")
            self.jira_jql_project_entry.config(state='disabled')
            
            self.pola_url.delete(0,tk.END)
            self.pola_url.insert(0,"10033679_MY22_AUDI_PODS_SDPS")
            self.pola_url.config(state='disabled')
            
            self.pola_url_1.delete(0,tk.END)
            self.pola_url_1.insert(0,r"http://polarionprod1.delphiauto.net/polarion")           
            self.pola_url_1.config(state='disabled')
            
            self.pola_url_type_ids.delete(0,tk.END)
            self.pola_url_type_ids.insert(0,"stakeholderRequirement,systemRequirement")              
            self.pola_url_type_ids.config(state='disabled')
            
            self.spo_url_project_entry.delete(0,tk.END)
            self.spo_url_project_entry.insert(0,r"https://lnttsgroup.sharepoint.com/sites/PODS/Lists/PODS_Audi/AllItems.aspx")             
            self.spo_url_project_entry.config(state='disabled')
        else:
            self.jira_jql_project_entry.config(state='normal')
            self.jira_jql_project_entry.delete(0,tk.END)
            self.jira_jql_project_entry.insert(0,"")
            
            self.pola_url.config(state='normal')
            self.pola_url.delete(0,tk.END)
            self.pola_url.insert(0,"")
            
            self.pola_url_1.config(state='normal')
            self.pola_url_1.delete(0,tk.END)
            self.pola_url_1.insert(0,r"")           
            
            self.pola_url_type_ids.config(state='normal')
            self.pola_url_type_ids.delete(0,tk.END)
            self.pola_url_type_ids.insert(0,"")              
            
            self.spo_url_project_entry.config(state='normal')
            self.spo_url_project_entry.delete(0,tk.END)
            self.spo_url_project_entry.insert(0,"")             
    def modified_dw(self,_):
        self.disabler()
        print(self.n.get())
        #cjsg
    def exicuter(self):
        
        info_dict = {
            'url' : 	self.pola_url_1.get()	,	
            'username': self.jira_user_id.get()                         ,	
            'password': self.jira_pwd.get()	                            ,	
            'project_id' : self.pola_url.get()           	,	
            'type_ids' : list(set(self.pola_url_type_ids.get().split(',')))	,
            'jiraURL': r"http://jiraprod1.delphiauto.net:8080"			,
            'jiraURL_1': r"http://nlskaa56.europe.delphiauto.net:8080"  ,
            'block_size' : 1000                                         ,
            'block_num' : 0                                             ,
            'Project_Name' : "DVJ"	                                    ,
            'CHROME_DRIVER_PATH' : r"C:\Webdriver\chromedriver.exe"		,
            'conditions_word_list' : conditions_word_list				,
            'list_of_phrases' : list_of_phrases							,
            'REVIEW_DBLINK' : "http://pep.usinkok.northamerica.delphiauto.net/projectdb/public/" ,
            'S_URL' : self.spo_url_project_entry.get()	  ,
        }
        
        print(info_dict)
        main_runner(info_dict)
        
######################################################################################################################################################################################################  

          
def appliction():
    root = tk.Tk()
    app = polarion_gui()
    app.starter(root)
    root.mainloop()
	

if __name__ == '__main__':
    appliction()