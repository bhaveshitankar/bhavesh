if __name__ == '__main__':
    import os
    try:
        PYTHON_PATH = raw_input("Enter path for python 3.7.3 : ")
    except:
        PYTHON_PATH = input("Enter path for python 3.7.3 : ")
    with open("run_all_bat.bat","w") as FH:
        write_str = '''
echo off

cd "scripts\Data_extractors"

"%s" "JIRA_POL_GUI.py"

cd \..\..
pause         
        ''' % PYTHON_PATH
        FH.write(write_str)
    with open(r"requirements.txt","r") as FH:
        for line in FH:
            os.system(PYTHON_PATH+" -m pip install "+line)